#pragma once
#include "Fighter.h"

class AI {
	public:
		int aggro(Fighter& ryu);

	private:
		Fighter* x;
};

