#pragma once
#include "Fighter.h"
#include "Skill.h"
#include "Game.h"

int main() {
	Game streetFighter;
	return 0; 
}